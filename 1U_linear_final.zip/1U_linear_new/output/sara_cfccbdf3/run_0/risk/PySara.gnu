#_______________________________________________________________________________
#    ######   ####     ##             #####   #####     ##    #    #    ##      
#    #       #        #  #            #    #  #    #   #  #   ##  ##   #  #     
#    #####    ####   ######           #    #  #####   ######  # ## #  ######    
#    #            #  #    #           #    #  #    #  #    #  #    #  #    #    
#____######__#####___#____#___________#####___#____#__#____#__#____#__#____#____
#										   
#           ESA Debris Risk Assessment and Mitigation Analysis Tool             
#                                                                               
#             ---- DRAMA ( Re-entry Risk Analysis v 3.0.0 ) ---- 
#                               ESA July 2024                   
#                                                                               
#               main gnuplot driver file -PySara.gnu-  
#                           runID: PySara				   
#                   run date+time: Thu, Aug 20 2026 14:31:57			   
#_______________________________________________________________________________
# 
 
set auto 
load "PySara.Pc_1D-Total.gnu" 
load "PySara.Pf_1D-Total.gnu" 
load "PySara.Pi_1D-Total.gnu" 

