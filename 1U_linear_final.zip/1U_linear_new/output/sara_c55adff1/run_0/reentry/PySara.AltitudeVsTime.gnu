reset
set datafile separator whitespace
set term png size 960,480

set o 'PySara.AltitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid

set key font ",7"
set key below 
set title 'Altitude vs Time of all Objects'noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' pt 1 ps 3

plot \
'PySara.Compound_of-ANTENNA-EPS-COMM-SOLAR_PANEL+X-SOLAR_PANEL-X-SOLAR_PANEL+Y-Solar_panel-y-SOLAR_PANEL+Z-SOLAR_PANEL-Z-OBC-ADCS-PAYLOAD-Structure.11290409376988533268_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.Compound_of-ANTENNA-EPS-Solar_panel-y-SOLAR_PANEL+Y-COMM-SOLAR_PANEL-Z-SOLAR_PANEL+Z-OBC-ADCS-PAYLOAD-Structure.17632830790014210966_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.Compound_of-ANTENNA-EPS-SOLAR_PANEL-Z-SOLAR_PANEL+Z-COMM-OBC-ADCS-PAYLOAD-Structure.9863225602673091367_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.Compound_of-ANTENNA-EPS-SOLAR_PANEL+Z-COMM-OBC-ADCS-PAYLOAD-Structure.7731714265017660442_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.Compound_of-ANTENNA-EPS-COMM-OBC-ADCS-PAYLOAD-Structure.2488044799013428273_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.ANTENNA.ef1decee-a1e9-480f-b2d1-264eddd0b744_Trajectory.txt' using 1:2 w l lw 3 title 'ANTENNA' noenhanced, \
'PySara.EPS.c6f93ddd-13e8-4599-b4e2-9b50c6ce708d_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.COMM.5ec80fef-472a-49e4-8831-11217eacc162_Trajectory.txt' using 1:2 w l lw 3 title 'COMM' noenhanced, \
'PySara.OBC.4a9aeba4-5db7-410e-87ac-ff00eb69a367_Trajectory.txt' using 1:2 w l lw 3 title 'OBC' noenhanced, \
'PySara.ADCS.e47378b3-1487-48d7-99ad-2143d6155f1d_Trajectory.txt' using 1:2 w l lw 3 title 'ADCS' noenhanced, \
'PySara.PAYLOAD.83963a6f-141e-4505-8936-17fa406040df_Trajectory.txt' using 1:2 w l lw 1 title '', \
'PySara.demiseData.txt' using 1:2 w p ls 1 lw 3 title 'Demise points', \
'PySara.uncriticalData.txt' using 1:2 w p ls 4 lw 3 title 'Uncritical points', \
 
