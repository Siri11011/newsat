 
set datafile separator whitespace
set term png size 960,480
 
set o 'PySara.SOLAR_PANEL-X.3588f412-e9fb-46f8-af4f-ccea773f37e9_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of SOLAR_PANEL-X (3588f412-e9fb-46f8-af4f-ccea773f37e9)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'PySara.SOLAR_PANEL-X.3588f412-e9fb-46f8-af4f-ccea773f37e9_Trajectory.txt' using 1:2 w l ls 1 title 'SOLAR_PANEL-X' noenhanced, \
 
set o 'PySara.SOLAR_PANEL-X.3588f412-e9fb-46f8-af4f-ccea773f37e9_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of SOLAR_PANEL-X (3588f412-e9fb-46f8-af4f-ccea773f37e9)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'PySara.SOLAR_PANEL-X.3588f412-e9fb-46f8-af4f-ccea773f37e9_Trajectory.txt' using 6:2 w l ls 1 title 'SOLAR_PANEL-X' noenhanced
 
