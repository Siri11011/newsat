 
set datafile separator whitespace
set term png size 960,480
 
set o 'PySara.ADCS.e47378b3-1487-48d7-99ad-2143d6155f1d_altitudeVsTime.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Time of ADCS (e47378b3-1487-48d7-99ad-2143d6155f1d)' noenhanced font ",14"
set xlabel 'Time [s]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
set style line 1 lc rgb 'blue' lw 3 pt 1 ps 3
 
plot 'PySara.ADCS.e47378b3-1487-48d7-99ad-2143d6155f1d_Trajectory.txt' using 1:2 w l ls 1 title 'ADCS' noenhanced, \
 
set o 'PySara.ADCS.e47378b3-1487-48d7-99ad-2143d6155f1d_altitudeVsDownrange.png'
set size 1,1 
set origin 0,0
set grid
 
set key font ",14"
set title 'Altitude vs Downrange of ADCS (e47378b3-1487-48d7-99ad-2143d6155f1d)' noenhanced font ",14"
set xlabel 'Downrange [Km]' font ",14"
set ylabel 'Altitude [Km]' font ",14"
set tics font ",14"
 
plot 'PySara.ADCS.e47378b3-1487-48d7-99ad-2143d6155f1d_Trajectory.txt' using 6:2 w l ls 1 title 'ADCS' noenhanced
 
