#_______________________________________________________________________________
#    ######   ####     ##             #####   #####     ##    #    #    ##      
#    #       #        #  #            #    #  #    #   #  #   ##  ##   #  #     
#    #####    ####   ######           #    #  #####   ######  # ## #  ######    
#    #            #  #    #           #    #  #    #  #    #  #    #  #    #    
#____######__#####___#____#___________#####___#____#__#____#__#____#__#____#____
#										   
#           ESA Debris Risk Assessment and Mitigation Analysis Tool             
#                                                                               
#             ---- DRAMA ( Re-entry Risk Analysis v 3.0.0 ) ---- 
#                               ESA July 2024                   
#                                                                               
#               gnuplot driver file -PySara.Pi_1D-Fragment-c6f93ddd-13e8-4599-b4e2-9b50c6ce708d.gnu-  
#                           runID: PySara				   
#                   run date+time: Thu, Aug 27 2026 12:04:06			   
#_______________________________________________________________________________
# 
 
reset															
set datafile separator ','														
set style data lines															
set term png																
set xlabel 'Lat [deg]'															
set xrange[-5.0:+5.0]									
set xtics nomirror																
set mxtics 4																		
set grid xtics ytics																
show grid																		
 																				
set title "DRAMA-SERAM\nimpact prob. for an uncontrolled re-entry from a near circular orbit \nrun ID: PySara\nResults: Fragment-c6f93ddd-13e8-4599-b4e2-9b50c6ce708d"															
set ylabel 'Impact Prob.[-]'											
set ytics nomirror																
set mytics 4																		
set format y '%.1te%+02T'														
set output 'PySara.Pi_1D-Fragment-c6f93ddd-13e8-4599-b4e2-9b50c6ce708d.png'														
plot 'PySara.Risk-Fragment-c6f93ddd-13e8-4599-b4e2-9b50c6ce708d.dat' u 1:2 w steps lt 01 lw 01 notitle			

